<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

//    protected $fillable = ['product_name', 'product_category', 'brand_name', 'product_price', 'product_image', 'product_description', '	status'];



    protected static $product;
    protected static $image;
    protected static $imageName;
    protected static $directory;
    protected static $imageUrl;

    public static function SaveData($request)
    {
        self::$image = $request->file('product_image');
        $imageName = time().rand(10,1000).'.'.self::$image->getClientOriginalExtension();
        self::$directory = 'assets/img/product-img/';
        self::$image->move(self::$directory, self::$imageName);
        self::$imageUrl = self::$directory.self::$imageName;

        self::$product = new Product();
        self::$product->product_name          = $request->product_name;
        self::$product->product_category      = $request->product_category;
        self::$product->brand_name            = $request->brand_name;
        self::$product->product_price         = $request->product_price;
        self::$product->product_image         = $imageUrl;
        self::$product->product_description   = $request->product_description;
        self::$product->status                = $request->status;
        self::$product->save();
    }
}
